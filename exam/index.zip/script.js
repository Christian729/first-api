function disappear(element){
    element.innerText = "";
}

var spanText1= document.querySelector(".num");
var spanText2= document.querySelector(".num1");
var spanText3= document.querySelector(".num2");

function pet1(){
    spanText1.innerText++;
    console.log(spanText1);
}



function pet2(){
    spanText2.innerText++;
    console.log(spanText2);
}




function pet3(){
    spanText3.innerText++;
    console.log(spanText3);
}

