var spanText= document.querySelector
('span')

function Like(){
    spanText.innerText++
    console.log(0)
}