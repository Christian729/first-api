var spanText1= document.querySelector(".num");
var spanText2= document.querySelector(".num1");
var spanText3= document.querySelector(".num2");

function like1(){
    spanText1.innerText++;
    console.log(spanText1);
}



function like2(){
    spanText2.innerText++;
    console.log(spanText2);
}




function like3(){
    spanText3.innerText++;
    console.log(spanText3);
}