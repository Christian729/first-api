function example(element){
    element.innerText = "Logout";
}

function disappear(element){
    element.innerText = "";
}

